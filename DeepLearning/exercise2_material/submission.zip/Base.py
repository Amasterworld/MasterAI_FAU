class BaseLayer:
    def __init__(self) -> None:
        trainable = False